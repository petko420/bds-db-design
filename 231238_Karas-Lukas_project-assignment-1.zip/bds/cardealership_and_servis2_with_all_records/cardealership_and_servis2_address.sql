-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: cardealership_and_servis2
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(45) NOT NULL,
  `street` varchar(45) NOT NULL,
  `house_number` varchar(45) DEFAULT NULL,
  `zip_code` varchar(45) DEFAULT NULL,
  `country` varchar(45) NOT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'Brno','Balbínova','784','60200','Czech Republic'),(2,'Praha','Čapkova','100','10700','Czech Republic'),(3,'Pardubice','Dubová','78','53301','Czech Republic'),(4,'Košice','Dúhová','48','04014','Slovakia'),(5,'Los Angeles','Hollywood Boulevard','CA 90069','90006','USA'),(6,'New York','Park Avenue','10001','10007','USA'),(7,'Chicago','Clark Street','8889','60007','USA'),(8,'Los Angeles','Woods Avenue','CA 84924','90006','USA'),(9,'Seattle','Pike Street','849','98111','USA'),(10,'Boston','Newbury Street','1384','02108','USA'),(11,'San Francisco','Hyde Street','8486','94016','USA'),(12,'Austin','Sixth Sreet','1234','73301','USA'),(13,'New Orleans','Bourbon Sreet','4865','70043','USA'),(14,'San Diego','El Prado','4512','22400','USA'),(15,'Houston','Main Sreet','878','77006','USA'),(16,'Detroit','Grand River Avenue','5448','48207','USA'),(17,'Toronto','Alexander Street','8496','66777','Canada'),(18,'Vancouver','Marine Drive NW','1284','98660','Canada'),(19,'Montréal','Ste. Catherine Street','4878','H1A 0A1','Canada'),(20,'Ottawa','Wellington Street','1205','K1R','Canada'),(21,'Calgary','7 Avenue S','159','T2N','Canada'),(22,'Edmonton','Silver Berry','487','T5S','Canada'),(23,'Winnipeg','Riverside Drive East','263','R2P','Canada'),(24,'Windsor','Riverside Drive','68','80528','UK'),(25,'London','Abbey Road','2','E1 6AN','UK'),(26,'Glasgow','Dowanside Road,W2','12','G33','UK'),(27,'Birmingham','Floodgate Street','84','35005','UK'),(28,'Bristol','Abbey Close','35','06010','UK'),(29,'Edinburgh','Princes Street','47','78504','UK'),(30,'Manchester','Deansgate','89','M40','UK'),(31,'Liverpool','Penny Lane','23','L1 0AA','UK'),(32,'Cardiff','Aber Street CF11 7AG','14','CF10','UK'),(33,'Nottingham','Aaron Close NG11 7DJ','06','NG1 1AQ','UK'),(34,'Portsmouth','Alliance Way','07','03801','UK'),(35,'Leicester','Abbey Street','05','LE1 1DA','UK'),(36,'Plymouth','1st Avenue 2360','66','02532','UK'),(37,'Mexico city','Avenida Álvaro Obregón','142','00810','Mexico'),(38,'Guadalajara','Avenida Juárez','789','44100','Mexico'),(39,'Merida','Paseo de Montejo','162','97000','Mexico'),(40,'Tjuana','Avenida Aldrete','148','20631','Mexico'),(41,'Cancún','La Costa','236','74526','Mexico'),(42,'Puebla','Av 23 Pte','984','72000','Mexico'),(43,'Naucalpan','C.Capulin','784','11220','Mexico'),(44,'Thalnepantla','C. Emilio Cárdenas','124','07268','Mexico'),(45,'Ojo de Agua','C.Denia','369','55764','Mexico'),(46,'Xico','Tolintla','847','91240','Mexico'),(47,'Toluca','Tule','320','50000','Mexico'),(48,'Buenavista','Hierro','481','81211','Mexico'),(49,'San Pablo de las Salinas','Acapulco','103','54911','Mexico'),(50,'Colima','Mérida','842','28000','Mexico'),(51,'Lima','Pedro Davalos','394','02002','Peru'),(52,'Cuzco','Ucayali','128','08001','Peru'),(53,'Arequipa','Barriga','129','04017','Peru'),(54,'Trujillo','Federico Chopin','842','13001','Peru'),(55,'Berlin','Kaiserdamm','128','10115','Germany'),(56,'Hamburg','Reimerstwiete','485','20149','Germany'),(57,'Munich','Isarring','128','80634','Germany'),(58,'Cologne','Am Hof','817','50667','Germany');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-02 16:21:03
