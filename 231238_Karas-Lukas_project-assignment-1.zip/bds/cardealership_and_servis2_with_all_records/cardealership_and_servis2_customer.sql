-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: cardealership_and_servis2
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Phone` varchar(45) NOT NULL,
  `Mail` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Jan','Nový','+420 687 458 156','janko.novy@seznam.cz'),(2,'Tomáš','Našel','+420 945 153 458','tomas.naselse@seznam.cz'),(3,'Sabina','Veselá','+420 315 158 489','sabina.veselka@seznam.cz'),(4,'Vincent','Juránek','+421 648 489 999','vincent.jur@zoznam.sk'),(5,'John','White','+1 153 144 543','john.white@gmail.com'),(6,'David','Green','+1 486 458 452','david.green@gmail.com'),(7,'William','Wright','+1 487 421 235','william.wright@yahoo.com'),(8,'Joseph','Johnson','+1 123 458 489','joeph.johnson@gmail.com'),(9,'Thomas','Edwards','+1 487 452 123','thomas.edwards@yahoo.com'),(10,'Matthew','Clark','+1 487 452 129','matthew.clark@gmail.com'),(11,'Anthony','Roberts','+1 125 487 522','anthony.roberts@gmail.com'),(12,'Steven','Robinson','+1 485 154 586','steven.robinson@gmail.com'),(13,'Paul','Hall','+1 123 458 486','paul.hall@gmail.com'),(14,'Kenneth','Lewis','+1 487 452 125','kenneth.lewis@gmail.com'),(15,'Kevin','Clarke','+1 854 245 123','kevin.clarke@gmail.com'),(16,'Brian','Young','+1 485 486 984','brian.young@gmail.com'),(17,'George','Davis','+1 123 125 484','george.davis@gmail.com'),(18,'Edward','Turner','+1 841 236 489','edward.turner@gmail.com'),(19,'Ronald','Hill','+44 485 125 458','ronald.hill@gmail.com'),(20,'Timothy','Phillips','+44 425 123 489','timothy.phillips@gmail.com'),(21,'Jason','Collins','+44 125 125 123','jason.collins@gmail.com'),(22,'Jeffrey','Allen','+44 542 153 486','jeffrey.allen@gmail.com'),(23,'Oliver','Smith','+44 485 624 126','oliver.smith@gmail.com'),(24,'George','Jones','+44 845 155 256','george.jones@gmail.com'),(25,'Noah','Taylor','+44 847 985 123','noah.taylor@gmail.com'),(26,'Arthur','Williams','+44 487 545 123','arthur.williams@gmail.com'),(27,'Harry','Brown','+44 847 984 123','harry.brown@gmail.com'),(28,'Leo','White','+44 485 125 883','leo.white@gmail.com'),(29,'Muhammad','Harris','+44 125 366 849','muhammad.harris@gmail.com'),(30,'Jack','Martin','+44 486 458 215','jack.martin@gmail.com'),(31,'Charlie','Davies','+44 487 456 159','charlie.davies@gmail.com'),(32,'José Luis','Hernández','+52 124 486 542','jose.hernandez@gmail.com'),(33,'Juan','Garcia','+52 485 648 486','juan.garcia@gmail.com'),(34,'Francisco','Martínez','+52 487 698 127','francisco.martinez@gmail.com'),(35,'Miguel Ángel','González','+52 406 102 106','miguelangel.gonzalez@gmail.com'),(36,'Francisco','López','+52 152 214 486','francisco.lopez@gmail.com'),(37,'Jesús','Rodríguez','+52 487 456 129','jesus.rodriguez@gmail.com'),(38,'Antonio','Pérez','+52 486 123 489','antonio.perez@gmail.com'),(39,'Alejandro','Sánchez','+52 489 486 123','alejandro.sanchez@gmail.com'),(40,'Pedro','Ramírez','+52 238 684 698','pedro.ramirez@gmail.com'),(41,'Juan Carlos','Gómez','+52 123 687 206','juan.gomez@gmail.com'),(42,'Manuel','Torres','+52 878 489 423','manuel.torres@gmail.com'),(43,'Ricardo','Díaz','+52 125 486 984','riciardo.diaz@gmail.com'),(44,'Daniel','Vásquez','+52 874 896 489','daniel.vasquez@gmail.com'),(45,'Fernando','Ramos','+52 632 498 818','fernando.ramos@gmail.com'),(46,'Alejandro','Aguilar','+51 485 126 235','alejandro.aguilar.gmail.com'),(47,'Brayan','Aguirre','+51 128 154 698','brayan.aguirre@gmail.com'),(48,'Dario','Diaz','+51 487 562 123','dario.diaz@gmail.com'),(49,'Edmundo','Guerra','+51 128 486 123','edmundo.guerra@gmail.com'),(50,'Jonas','Slim','+49 148 368 498','jonas.slim@gmail.com'),(51,'Ben','Schmidt','+49 124 487 689','ben.schmidt@gmail.com'),(52,'Tobias','Chneider','+49 84 789 479','tobias.chneider@gmail.com'),(53,'Elias','Fischer','+49 123 487 687','elias.fischer@gmail.com');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-02 16:21:05
