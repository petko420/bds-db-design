-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: cardealership_and_servis2
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `whosale_and_customer_have_address`
--

DROP TABLE IF EXISTS `whosale_and_customer_have_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `whosale_and_customer_have_address` (
  `salesperson_id` int DEFAULT NULL,
  `address_id` int NOT NULL,
  `customer_id` int DEFAULT NULL,
  PRIMARY KEY (`address_id`),
  UNIQUE KEY `salesperson_id_UNIQUE` (`salesperson_id`),
  UNIQUE KEY `customer_id_UNIQUE` (`customer_id`),
  KEY `fk_WhoSale_has_Address_Address1_idx` (`address_id`),
  KEY `fk_WhoSale_has_Address_WhoSale1_idx` (`salesperson_id`),
  KEY `fk_WhoSale_has_Address_Customer1_idx` (`customer_id`),
  CONSTRAINT `fk_WhoSale_has_Address_Address1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`),
  CONSTRAINT `fk_WhoSale_has_Address_Customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `fk_WhoSale_has_Address_WhoSale1` FOREIGN KEY (`salesperson_id`) REFERENCES `whosale` (`salesperson_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whosale_and_customer_have_address`
--

LOCK TABLES `whosale_and_customer_have_address` WRITE;
/*!40000 ALTER TABLE `whosale_and_customer_have_address` DISABLE KEYS */;
INSERT INTO `whosale_and_customer_have_address` VALUES (NULL,1,1),(NULL,2,2),(NULL,3,3),(NULL,4,4),(1,5,NULL),(2,6,NULL),(3,7,NULL),(4,8,NULL),(5,9,NULL),(NULL,10,5),(NULL,11,6),(NULL,12,7),(NULL,13,8),(NULL,14,9),(NULL,15,10),(NULL,16,11),(NULL,17,12),(NULL,18,13),(NULL,19,14),(NULL,20,15),(NULL,21,16),(NULL,22,17),(NULL,23,18),(NULL,24,19),(NULL,25,20),(NULL,26,21),(NULL,27,22),(NULL,28,23),(NULL,29,24),(NULL,30,25),(NULL,31,26),(NULL,32,27),(NULL,33,28),(NULL,34,29),(NULL,35,30),(NULL,36,31),(NULL,37,32),(NULL,38,33),(NULL,39,34),(NULL,40,35),(NULL,41,36),(NULL,42,37),(NULL,43,38),(NULL,44,39),(NULL,45,40),(NULL,46,41),(NULL,47,42),(NULL,48,43),(NULL,49,44),(NULL,50,45),(NULL,51,46),(NULL,52,47),(NULL,53,48),(NULL,54,49),(NULL,55,50),(NULL,56,51),(NULL,57,52),(NULL,58,53);
/*!40000 ALTER TABLE `whosale_and_customer_have_address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-02 16:21:04
