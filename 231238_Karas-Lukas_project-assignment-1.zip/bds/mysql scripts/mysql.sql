-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Customer` (
  `customer_id` INT NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  `Phone` VARCHAR(45) NOT NULL,
  `Mail` VARCHAR(45) NULL,
  PRIMARY KEY (`customer_id`))
  ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Option`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Option` (
  `option_id` INT NOT NULL AUTO_INCREMENT,
  `engine` VARCHAR(45) NOT NULL,
  `transmission` VARCHAR(45) NOT NULL,
  `equipment` VARCHAR(45) NOT NULL,
  `wheels` VARCHAR(45) NULL,
  PRIMARY KEY (`option_id`))
  ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Car`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Car` (
  `car_id` INT NOT NULL AUTO_INCREMENT,
  `brand` VARCHAR(45) NOT NULL,
  `model` VARCHAR(45) NOT NULL,
  `year` INT NOT NULL,
  `VIN` INT NOT NULL,
  `colour` MEDIUMTEXT NOT NULL,
  `option_id` INT NOT NULL,
  PRIMARY KEY (`car_id`, `option_id`),
  INDEX `fk_Car_Option1_idx` (`option_id` ASC),
  CONSTRAINT `fk_Car_Option1`
    FOREIGN KEY (`option_id`)
    REFERENCES `cardealership_and_servis2`.`Option` (`option_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`WhoSale`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`WhoSale` (
  `salesperson_id` INT NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  `Phone` VARCHAR(45) NOT NULL,
  `Mail` VARCHAR(45) NULL,
  PRIMARY KEY (`salesperson_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Sales Invoice`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Sales Invoice` (
  `salesinvoice_id` INT NOT NULL AUTO_INCREMENT,
  `Invoice Number` INT NOT NULL,
  `Date` DATE NOT NULL,
  `customer_id` INT NOT NULL,
  `car_id` INT NOT NULL,
  `salesperson_id` INT NOT NULL,
  PRIMARY KEY (`salesinvoice_id`, `car_id`, `salesperson_id`),
  INDEX `fk_Sales Invoice_Customer1_idx` (`customer_id` ASC),
  INDEX `fk_Sales Invoice_Car1_idx` (`car_id` ASC) VISIBLE,
  INDEX `fk_Sales Invoice_WhoSale1_idx` (`salesperson_id` ASC),
  CONSTRAINT `fk_Sales Invoice_Customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `cardealership_and_servis2`.`Customer` (`customer_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Sales Invoice_Car1`
    FOREIGN KEY (`car_id`)
    REFERENCES `cardealership_and_servis2`.`Car` (`car_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Sales Invoice_WhoSale1`
    FOREIGN KEY (`salesperson_id`)
    REFERENCES `cardealership_and_servis2`.`WhoSale` (`salesperson_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Service ticket`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Service ticket` (
  `serviceticket_id` INT NOT NULL AUTO_INCREMENT,
  `number` INT NOT NULL,
  `date_recived` DATE NOT NULL,
  `date_return` DATE NOT NULL,
  `customer_id` INT NOT NULL,
  `car_id` INT NOT NULL,
  PRIMARY KEY (`serviceticket_id`, `car_id`),
  INDEX `customer_id_idx` (`customer_id` ASC),
  INDEX `fk_Service ticket_Car1_idx` (`car_id` ASC),
  CONSTRAINT `customer_id`
    FOREIGN KEY (`customer_id`)
    REFERENCES `cardealership_and_servis2`.`Customer` (`customer_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Service ticket_Car1`
    FOREIGN KEY (`car_id`)
    REFERENCES `cardealership_and_servis2`.`Car` (`car_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Mechanic`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Mechanic` (
  `mechanic_id` INT NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`mechanic_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Service`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Service` (
  `service_id` INT NOT NULL AUTO_INCREMENT,
  `ServiceName` VARCHAR(45) NOT NULL,
  `Number_of_hours` INT NOT NULL,
  PRIMARY KEY (`service_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Service Mechanic`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Service Mechanic` (
  `servicemechanic_id` INT NOT NULL AUTO_INCREMENT,
  `hours` INT NULL,
  `Rate (5 is the highest)` INT NULL,
  `has_been_working_here_since` DATE NOT NULL,
  `postition` VARCHAR(45) NOT NULL,
  `mechanic_id` INT NOT NULL,
  `serviceticket_id` INT NOT NULL,
  `service_id` INT NOT NULL,
  PRIMARY KEY (`servicemechanic_id`, `mechanic_id`),
  INDEX `fk_Service Mechanic_Mechanic1_idx` (`mechanic_id` ASC),
  INDEX `fk_Service Mechanic_Service ticket1_idx` (`serviceticket_id` ASC),
  INDEX `fk_Service Mechanic_Service1_idx` (`service_id` ASC),
  CONSTRAINT `fk_Service Mechanic_Mechanic1`
    FOREIGN KEY (`mechanic_id`)
    REFERENCES `cardealership_and_servis2`.`Mechanic` (`mechanic_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Service Mechanic_Service ticket1`
    FOREIGN KEY (`serviceticket_id`)
    REFERENCES `cardealership_and_servis2`.`Service ticket` (`serviceticket_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Service Mechanic_Service1`
    FOREIGN KEY (`service_id`)
    REFERENCES `cardealership_and_servis2`.`Service` (`service_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Supplier`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Supplier` (
  `supplier_id` INT NOT NULL AUTO_INCREMENT,
  `supplier_name` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  `street` VARCHAR(45) NOT NULL,
  `zip_code` VARCHAR(45) NOT NULL,
  `country` VARCHAR(45) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`supplier_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Part_used`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Part_used` (
  `parts_id` INT NOT NULL AUTO_INCREMENT,
  `part_number` INT NOT NULL,
  `purchase_price` INT NOT NULL,
  `retail_price` INT NOT NULL,
  `description` VARCHAR(45) NOT NULL,
  `supplier_id` INT NOT NULL,
  `serviceticket_id` INT NOT NULL,
  PRIMARY KEY (`parts_id`, `supplier_id`, `serviceticket_id`),
  INDEX `fk_Parts_Supplier1_idx` (`supplier_id` ASC),
  INDEX `fk_Part_used_Service ticket1_idx` (`serviceticket_id` ASC),
  CONSTRAINT `fk_Parts_Supplier1`
    FOREIGN KEY (`supplier_id`)
    REFERENCES `cardealership_and_servis2`.`Supplier` (`supplier_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Part_used_Service ticket1`
    FOREIGN KEY (`serviceticket_id`)
    REFERENCES `cardealership_and_servis2`.`Service ticket` (`serviceticket_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`Address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`Address` (
  `address_id` INT NOT NULL AUTO_INCREMENT,
  `city` VARCHAR(45) NOT NULL,
  `street` VARCHAR(45) NOT NULL,
  `house_number` VARCHAR(45) NULL,
  `zip_code` VARCHAR(45) NULL,
  `country` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`address_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `cardealership_and_servis2`.`WhoSale_and_customer_have_Address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cardealership_and_servis2`.`WhoSale_and_customer_have_Address` (
  `salesperson_id` INT NULL,
  `address_id` INT NOT NULL,
  `customer_id` INT NULL,
  PRIMARY KEY (`address_id`),
  INDEX `fk_WhoSale_has_Address_Address1_idx` (`address_id` ASC),
  INDEX `fk_WhoSale_has_Address_WhoSale1_idx` (`salesperson_id` ASC),
  INDEX `fk_WhoSale_has_Address_Customer1_idx` (`customer_id` ASC),
  UNIQUE INDEX `salesperson_id_UNIQUE` (`salesperson_id` ASC),
  UNIQUE INDEX `customer_id_UNIQUE` (`customer_id` ASC),
  CONSTRAINT `fk_WhoSale_has_Address_WhoSale1`
    FOREIGN KEY (`salesperson_id`)
    REFERENCES `cardealership_and_servis2`.`WhoSale` (`salesperson_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_WhoSale_has_Address_Address1`
    FOREIGN KEY (`address_id`)
    REFERENCES `cardealership_and_servis2`.`Address` (`address_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_WhoSale_has_Address_Customer1`
    FOREIGN KEY (`customer_id`)
    REFERENCES `cardealership_and_servis2`.`Customer` (`customer_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;