CREATE TABLE IF NOT EXISTS "Customer" (
  "customer_id" serial primary key not null,
  "FirstName" VARCHAR(45) NOT NULL,
  "LastName" VARCHAR(45) NOT NULL,
  "Phone" VARCHAR(45) NOT NULL,
  "Mail" VARCHAR(45)
	);

CREATE TABLE IF NOT EXISTS "WhoSale" (
  "salesperson_id" serial primary key not null,
  "FirstName" VARCHAR(45) NOT NULL,
  "LastName" VARCHAR(45) NOT NULL,
  "Phone" VARCHAR(45) NOT NULL,
  "Mail" VARCHAR(45)
  );

CREATE TABLE IF NOT EXISTS "Address" (
  "address_id" serial primary key not null,
  "city" VARCHAR(45) NOT NULL,
  "street" VARCHAR(45) NOT NULL,
  "house_number" VARCHAR(45),
  "zip_code" VARCHAR(45),
  "country" VARCHAR(45) NOT NULL
);

CREATE TABLE IF NOT EXISTS "WhoSale_and_customer_have_Address" (
  "salesperson_id" INT,
  "address_id" INT NOT NULL,
  "customer_id" INT,
  foreign key ("salesperson_id") references "WhoSale",
  foreign key ("address_id") references "Address",
  foreign key ("customer_id") references "Customer"
);

CREATE TABLE IF NOT EXISTS "Option" (
  "option_id" serial primary key not null,
  "engine" VARCHAR(45) NOT NULL,
  "transmission" VARCHAR(45) NOT NULL,
  "equipment" VARCHAR(45) NOT NULL,
  "wheels" VARCHAR(45)
  );

CREATE TABLE IF NOT EXISTS "Car" (
  "car_id" serial primary key not null,
  "brand" VARCHAR(45) NOT NULL,
  "model" VARCHAR(45) NOT NULL,
  "year" INT NOT NULL,
  "VIN" INT NOT NULL,
  "colour" VARCHAR(45) NOT NULL,
  "option_id" INT NOT NULL,
  foreign key ("option_id") references "Option"
);

CREATE TABLE IF NOT EXISTS "Service ticket" (
  "serviceticket_id" serial primary key not null,
  "number" INT NOT NULL,
  "date_recived" DATE NOT NULL,
  "date_return" DATE NOT NULL,
  "customer_id" INT NOT NULL,
  "car_id" INT NOT NULL,
  foreign key ("customer_id") references "Customer",
  foreign key ("car_id") references "Car"
);

CREATE TABLE IF NOT EXISTS "Sales Invoice" (
  "salesinvoice_id" serial primary key not null,
  "Invoice Number" INT NOT NULL,
  "Date" DATE NOT NULL,
  "customer_id" INT NOT NULL,
  "car_id" INT NOT NULL,
  "salesperson_id" INT NOT NULL,
  foreign key ("customer_id") references "Customer",
  foreign key ("car_id") references "Car",
  foreign key ("salesperson_id") references "WhoSale"
);

CREATE TABLE IF NOT EXISTS "Mechanic" (
  "mechanic_id" serial primary key not null,
  "FirstName" VARCHAR(45) NOT NULL,
  "LastName" VARCHAR(45) NOT NULL
);

CREATE TABLE IF NOT EXISTS "Service" (
  "service_id" serial primary key not null,
  "ServiceName" VARCHAR(45) NOT NULL,
  "Number_of_hours" INT NOT NULL
);

CREATE TABLE IF NOT EXISTS "Service Mechanic" (
  "servicemechanic_id" serial primary key not null,
  "hours" INT,
  "Rate (5 is the highest)" INT,
  "has_been_working_here_since" DATE NOT NULL,
  "postition" VARCHAR(45) NOT NULL,
  "mechanic_id" INT NOT NULL,
  "serviceticket_id" INT NOT NULL,
  "service_id" INT NOT NULL,
  foreign key ("mechanic_id") references "Mechanic",
  foreign key ("serviceticket_id") references "Service ticket",
  foreign key ("service_id") references "Service"
);

CREATE TABLE IF NOT EXISTS "Supplier" (
  "supplier_id" serial primary key not null,
  "supplier_name" VARCHAR(45) NOT NULL,
  "city" VARCHAR(45) NOT NULL,
  "street" VARCHAR(45) NOT NULL,
  "zip_code" VARCHAR(45) NOT NULL,
  "country" VARCHAR(45) NOT NULL,
  "phone" VARCHAR(45) NOT NULL
);

CREATE TABLE IF NOT EXISTS "Part_used" (
  "parts_id" serial primary key not null,
  "part_number" INT NOT NULL,
  "purchase_price" INT NOT NULL,
  "retail_price" INT NOT NULL,
  "description" VARCHAR(45) NOT NULL,
  "supplier_id" INT NOT NULL,
  "serviceticket_id" INT NOT NULL,
  foreign key ("supplier_id") references "Supplier",
  foreign key ("serviceticket_id") references "Service ticket"
);